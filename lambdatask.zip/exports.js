var AWS = require('aws-sdk');
AWS.config.apiVersions = {
  cloudwatchevents: '2015-10-07',
};

var cloudwatchevents = new AWS.CloudWatchEvents();

exports.handler = (events, context) => {

  var rulename = events.rulename
  console.log("now invoking");
  var params = {
    Name: rulename
  };
  cloudwatchevents.disableRule(params, function(err, data) {
    if (err) console.log(err, err.stack); // an error occurred
    else console.log(data); // successful response
  });

  // var ecs_task_def = events.ecs_task_def || 'undefined'
  // var exec_region = events.region || 'us-east-1'
  // var cluster = events.cluster || 'default'
  // var count = events.count || 1
  // var launch_type = events.launch_type || "FARGATE"
  // var networkConfiguration = events.networkConfiguration;
  //
  // //////////////////
  // // network_configuration.security_groups = [events.security_groups];
  // // network_configuration.subnets = [events.subnets];
  // ////////////////
  // var params = {
  //   taskDefinition: ecs_task_def,
  //   cluster: cluster,
  //   count: count,
  //   networkConfiguration: networkConfiguration
  // }
  //
  // ecs.runTask(params, function(err, data) {
  //   if (err) console.log(err, err.stack); // an error occurred
  //   else console.log(data); // successful response
  //   context.done(err, data)
  // })

}
